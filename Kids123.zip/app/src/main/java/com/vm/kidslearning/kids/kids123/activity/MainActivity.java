package com.vm.kidslearning.kids.kids123.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Handler;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.vm.kidslearning.kids.kids123.R;
import com.vm.kidslearning.kids.kids123.adapter.GalleryAdapter;
import com.vm.kidslearning.kids.kids123.utility.GridSpacingItemDecoration;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView rc_categoryView;
    private GalleryAdapter mAdapter;
    private ProgressDialog pDialog;

    String imageFilePath = "file:///android_asset/dashboard/";
    private AssetManager assetManager;
    private ArrayList<String> image_assets;
    String[] imgPath;

    AdView mAdView;
    LinearLayout linearlayout;
    LinearLayout ad_mlayout,re_mlayout;
    InterstitialAd mInterstitialAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int spanCount = 2; // 2 columns
        int spacing =30; // 30px
        boolean includeEdge = true;

        rc_categoryView = findViewById(R.id.recycler_view);
        assetManager = getAssets();
        pDialog = new ProgressDialog(this);

        image_assets=new ArrayList<>();

        MobileAds.initialize(getApplicationContext(), "ca-app-pub-1113372948108698~7659497393");
        mAdView = (AdView) findViewById(R.id.adView_main);
        re_mlayout = findViewById(R.id.cat_Rclayout);
        ad_mlayout = findViewById(R.id.main_Adlayout);
        linearlayout=(LinearLayout) findViewById(R.id.cat_main_layout);

        AdRequest adRequest = new AdRequest.Builder().build();

        mAdView.loadAd(adRequest);

        mAdView.setAdListener(new AdListener() {
            @Override
            public void onAdLoaded() {
                super.onAdLoaded();
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0);
                params.weight=1;
                ad_mlayout.setLayoutParams(params);
                LinearLayout.LayoutParams params1 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0);
                params1.weight=9;
                re_mlayout.setLayoutParams(params1);
                mAdView.setVisibility(android.view.View.VISIBLE);
            }

            @Override
            public void onAdFailedToLoad(int errorCode) {
                super.onAdFailedToLoad(errorCode);
                mAdView.setVisibility(android.view.View.GONE);
            }
        });


        mAdapter = new GalleryAdapter(getApplicationContext(), image_assets);

        RecyclerView.LayoutManager mLayoutManager = new GridLayoutManager(this, 2);
        rc_categoryView.setLayoutManager(mLayoutManager);
        rc_categoryView.addItemDecoration(new GridSpacingItemDecoration(spanCount, spacing, includeEdge));

        rc_categoryView.setItemAnimator(new DefaultItemAnimator());
        rc_categoryView.setAdapter(mAdapter);

        rc_categoryView.addOnItemTouchListener(new GalleryAdapter.RecyclerTouchListener(this, rc_categoryView, new GalleryAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                Intent i = new Intent(getApplicationContext(),Detail_Activity.class);
                i.putExtra("position",String.valueOf(position));
                startActivity(i);
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        fetchImages();
    }

    private void fetchImages() {

        try {
            imgPath = assetManager.list("dashboard");
            Log.d("Path", imgPath.toString());
            //image_assets= Arrays.asList(imgPath);
            //Log.d("Path1", image_assets.toString());
            for (int i = 0; i< imgPath.length; i++) {
                image_assets.add(imageFilePath+imgPath[i]);
                Log.d("Completepath", imageFilePath+imgPath[i].toString());

            }
            mAdapter.notifyDataSetChanged();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    boolean doubleBackToExitPressedOnce = false;
    @Override
    public void onBackPressed() {

        if(doubleBackToExitPressedOnce)
        {
            mInterstitialAd = new InterstitialAd(getApplicationContext());

            // set the ad unit ID
            mInterstitialAd.setAdUnitId("ca-app-pub-1113372948108698/1471710604");

            AdRequest adRequestInter = new AdRequest.Builder()
                    .build();

            // Load ads into Interstitial Ads
            mInterstitialAd.loadAd(adRequestInter);

            mInterstitialAd.setAdListener(new AdListener() {
                public void onAdLoaded() {
                    showInterstitial();
                }
            });
            super.onBackPressed();

            return;
        }

        this.doubleBackToExitPressedOnce = true;

        Snackbar snackbar = Snackbar
                .make(linearlayout, "Tap Back Again to Exit", Snackbar.LENGTH_SHORT);

        snackbar.show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);

    }
    private void showInterstitial() {
        if (mInterstitialAd.isLoaded()) {
            mInterstitialAd.show();
        }
    }

    @Override
    public void onPause() {
        if (mAdView != null) {
            mAdView.pause();
        }
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mAdView != null) {
            mAdView.resume();
        }
    }

    @Override
    public void onDestroy() {
        if (mAdView != null) {
            mAdView.destroy();
        }
        super.onDestroy();
    }
}
