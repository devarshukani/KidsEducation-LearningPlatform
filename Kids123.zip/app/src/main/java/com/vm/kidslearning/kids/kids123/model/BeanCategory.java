package com.vm.kidslearning.kids.kids123.model;

/**
 * Created by VISHAL on 7/28/2019.
 */

public class BeanCategory {
    String CategoryID;
    String CategoryName;
    String CategoryImageURL;
    String CategoryRemarks;

    public String getCategoryID() {
        return CategoryID;
    }

    public void setCategoryID(String categoryID) {
        CategoryID = categoryID;
    }

    public String getCategoryName() {
        return CategoryName;
    }

    public void setCategoryName(String categoryName) {
        CategoryName = categoryName;
    }

    public String getCategoryImageURL() {
        return CategoryImageURL;
    }

    public void setCategoryImageURL(String categoryImageURL) {
        CategoryImageURL = categoryImageURL;
    }

    public String getCategoryRemarks() {
        return CategoryRemarks;
    }

    public void setCategoryRemarks(String categoryRemarks) {
        CategoryRemarks = categoryRemarks;
    }
}
